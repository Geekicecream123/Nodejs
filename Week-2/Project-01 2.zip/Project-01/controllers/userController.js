//@desc Register a user
//@route POST /api/users/register
//@access public
const User=require("../models/userModel")
const jwt=require("jsonwebtoken");
const bcrypt=require("bcrypt");
const asyncHandler=require("express-async-handler");
const registerUser=asyncHandler(async (_req,res) =>{
    const {username,email,password}=_req.body;
    if (!username || !email || !password){
        res.status(400);
        throw new Error("All fields are mandatory")
    }
    const useravailable = await User.findOne({email});

    if (useravailable) {
        res.status(400);
        throw new Error("User already registered")
    }

    //hash password
    const hashedPassword=await bcrypt.hash(password,10);
    console.log(hashedPassword);

    const user=await User.create({
        username,
        email,
        password:hashedPassword
    })

    if (user){
        res.status(201).json({_id:user.id,email:user.email})}

        else {
            res.status(400);
            throw new  Error("user data not valid")
        }
    
    res.json({message:"Register the user"});
});


//@desc login user
//@route POST /api/users/login
//@access public

const loginUser=asyncHandler(async (_req,res) =>{
    const {email,password}=_req.body;
    if(!email || !password){
        res.status(400);
        throw new Error("All field are mandatory ")
    }

    const user=await User.findOne({email})

    if(user &&(await bcrypt.compare(password,user.password))){
        const accessToken=jwt.sign({
            user:{
                username:user.username,
                email:user.email,
                id:user.id
            }
        },
        process.env.ACCESS_TOKEN_SECRET,
        {expiresIn:"1m"})
        res.status(200).json({accessToken})
        //accesstoke helpconvert public-->private routes
        //this t
    }else {
        res.status(401)
        throw new Error("email or password is required")
    }
   
});
//@desc get current user info
//@route POST /api/users/login
//@access private
const currentUser=asyncHandler(async (_req,res) =>{
    res.json({message:"Register the user"});
});

module.exports={registerUser,loginUser,currentUser}

