const asyncHandler=require("express-async-handler")
const Contact=require("../models/contactModel")

const getContacts=asyncHandler(async(_req,res) =>{
    res.status(200).json({message:"Get all contacts"});
})
//don't need try&catch block with async handler
const createContact= asyncHandler(async (_req,res) =>{
    console.log("Request body is:",_req.body);

    const {name,email,phone}=_req.body;
    if(!name || !email || !phone){
        res.status(400);
        throw new Error("All fields are mandatory");
    }
    

    const contact=await Contact.create({
        name,
        email,
        phone
        //user_id:_req.user.id
    });

    res.status(201).json(contact);
})

const getContact=asyncHandler(async (_req,res) =>{
    const contact = await Contact.findById(_req.params.id);
    if(!contact){
        res.status(404);
        throw new Error("Contact not found");
    }
    //res.status(200).json({message:`Get contact for ${_req.params.id}`});
    res.status(200).json(contact);
})

const updateContact=asyncHandler(async (_req,res) => {
    const contact = await Contact.findById(_req.params.id);
    if(!contact){
        res.status(404);
        throw new Error("Contact not found");
    }
    const updatedContact=await Contact.findByIdAndUpdate(
        _req.params.id,
        _req.body,
        {new:true}
    )
    //res.status(200).json({message:`Update contact for ${_req.params.id}`});
    res.status(200).json(updatedContact)
})

const deleteContact=asyncHandler(async (_req,res) =>{
    const contact = await Contact.findById(_req.params.id);
    if(!contact){
        res.status(404);
        throw new Error("Contact not found");
    }
    await Contact.removeAllListeners();
    res.status(200).json(contact)
})




module.exports={getContacts,createContact,getContact,updateContact,deleteContact};