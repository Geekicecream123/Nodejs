const mongoose =require("mongoose");


const contactSchema=new mongoose.Schema({
    user_id:{
        type:mongoose.Schema.Types.ObjectId,
        required:true,
        ref:"user"
    },
    name:{
        type:String,
        required:[true,"Please add contact name"],

    },
    email:{
        type:String,
        required:[true,"Please add contact name"],

    },
    phone:{
        type:String,
        required:[true,"Please add contact name"],

    },
    timestamps:{
        type:String,
    }   
        

    

})

const User=mongoose.model("Contact",contactSchema)

module.exports=User;