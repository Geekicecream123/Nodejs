const mongoose =require("mongoose");


const userSchema=new mongoose.Schema({
    username:{
        type:String,
        required:[true,"Please add username"],

    },
    email:{
        type:String,
        required:[true,"Please add email"],

    },
    password:{
        type:String,
        required:[true,"Please add password"],

    },
    timestamps:{
        type:String,
    }   
        

    

})

const User=mongoose.model("User",userSchema)

module.exports=User;