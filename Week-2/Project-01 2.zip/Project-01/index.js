const http = require("http");
const fs = require("fs");
const url =require("url");

const express=require("express");
const errorHandler = require("./middleware/errorHandler");
const { connectmongodb } = require("./connection");




const app = express()
const dotenv=require("dotenv").config()
connectmongodb()
const port=process.env.PORT ||8000;

app.use(express.json());//provides parser to process data string

app.use("/api/contacts",require("./routes/contactRoutes"))//express checks till /user and forwards rest to userouter
app.use("/api/users",require("./routes/userRoutes"))
app.use(errorHandler);
app.listen(port,()=>{console.log(`Server started on port ${port}`);});