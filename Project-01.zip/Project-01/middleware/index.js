const fs=require("fs");

function logReqRes(filename){
    return(_req,res,next) => {
        fs.appendFile(
            filename,
            `\n${Date.now()}:${_req.ip} ${_req.method}:${_req.path}\n`,
            (err,data) =>{
                next();
            }
        );
    };
};

module.exports={logReqRes}