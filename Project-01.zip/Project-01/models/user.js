const mongoose =require("mongoose");


const userSchema=new mongoose.Schema({
    firstname:{
        type:String,
        required:true,

    },
    lastname:{
        type:String,
        //lastname is not necessarily required
    },
    email:{
        type:String,
        required:true,
        unique:true

    },
    gender:{
        type:String

    },
    ip_address:{
        type:String,
        
        

    },
    job_title:{
        type:String,

    }

})

const User=mongoose.model("user",userSchema)

module.exports=User;