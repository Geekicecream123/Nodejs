const http = require("http");
const fs = require("fs");
const url =require("url");

const express=require("express");

const users=require("./MOCK_DATA.json")
const {connectmongodb} =require("./routes/user");
const {logReqRes}=require("./middlewares");
const userRouter=require("./routes/user")
const app = express()

//connection
connectmongodb("mongodb://127.0.0.1:27017/youtube-app-1")

//Schema


//model
//middleware to convert form data from postman into body
app.use(express.urlencoded({extended:false}));
// //adding /api/users meaning it for non browser devices
app.use(logReqRes("log.txt"));
app.use("/user",userRouter);

// //req.method ;;;req.path
// app.use((_req,res,next)=>{
//     console.log("Hello from middle ware 1");
//     req.creditcardnumber='1'//make changes in the middle 
//     next();
// })

// app.use((_req,res,next)=>{
//     console.log("Hello from middle ware 2");
//     next()
//     return(res.end("Hey"));
    
// })
// app.get("/api/users", (_req,res) =>{return res.json(users)})
// app.post("/api/users",async (_req,res) =>{
//     const body=_req.body;
//     const result=await User.create({
//         firstname:body.first_name,
//         lastname:body.last_name,
//         email:body.email,
//         gender:body.gender,
//         jobTitle:body.job_title

//     });
//     console.log("Result",result)
//     return res.status(201).json({msg:"Success"})});

// app.get("/api/users/:id",(_req,res) =>{
//     // var id=Number(req.params.id);//convert string to number
//     // 

//     var id =_req.params['id']
//     //console.log("User ID :",id); 
//     const user=users.find((user) => user.id === id);
    
//     return res.json(user)
// })

// app.route('api/users')
//     .get((req, res, next) => {
//         res.send('GET request called');
//     })
//     .post((req, res, next) => {
//         res.send('POST request called');
//     })
//     .all((req, res, next) => {
//         res.send('Other requests called');
//     })

app.use("/user",userRouter)//express checks till /user and forwards rest to userouter
app.listen(8000,()=> console.log("Server started"));