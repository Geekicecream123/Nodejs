const express=require("express");
const router=express.Router();
const users=require("./MOCK_DATA.json")


router.get("/", (_req,res) =>{return res.json(users)})
router.post("/",async (_req,res) =>{
    const body=_req.body;
    const result=await User.create({
        firstname:body.first_name,
        lastname:body.last_name,
        email:body.email,
        gender:body.gender,
        jobTitle:body.job_title

    });
    console.log("Result",result)
    return res.status(201).json({msg:"Success"})});



module.exports=router


















module.exports=rouuter;